# This is the HNGX Task 1 for Backend Track from Ugbogu Justice George

# Endpoint

# Get Request

# Json Response